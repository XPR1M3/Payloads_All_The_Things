echo "Content-type: text/html"
echo ""
echo `id`
