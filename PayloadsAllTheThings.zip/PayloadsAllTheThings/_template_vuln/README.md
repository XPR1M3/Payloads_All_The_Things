# Vulnerability Title

> Vulnerability description - reference

Tools:

- [Tool name - description](https://example.com)

## Summary

* [Something](#something)
* [Something](#something)
  * [Subentry 1](#sub1)
  * [Subentry 2](#sub2)

## Something

Quick explanation

```powershell
Exploit
```

## References

- [Blog title - Author, Date](https://example.com)